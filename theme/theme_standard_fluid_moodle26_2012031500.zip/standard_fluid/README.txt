1.0 First Version

Standard Fluid extends the standard theme to a fluid template for browsers who understand media queries, simply by adding a short CSS File.
It's a good start if you like to code your own responsive web design theme in moodle.

Browsers who do not understand media queries (e.g. IE 8) are not affected and render as usual.